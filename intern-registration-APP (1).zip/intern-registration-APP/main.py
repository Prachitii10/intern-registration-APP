from flask import Flask, render_template, request, redirect

app = Flask(__name__, static_folder='static', template_folder='templates')

submissions = []  # List to store submitted form data


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/form')
def form():
    return render_template('form.html')


@app.route('/submit', methods=['POST'])
def submit():
    name = request.form.get('name')
    email = request.form.get('email')
    interest = request.form.get('interest')

    # Save form data to list
    submissions.append({'name': name, 'email': email, 'interest': interest})

    return redirect('/admin')


@app.route('/admin')
def admin():
    return render_template('admin.html', submissions=submissions)


app.run(host='0.0.0.0', port=3000)
